import { useState } from 'react'
import { Container } from 'react-bootstrap'

import Header from './components/Header'
import Intro from './components/Intro'
import SkillsSection from './components/SkillsSection'
import ProjectsSection from './components/ProjectsSection'
import RecommendationsSection from './components/RecommendationsSection'
import LeaveRecommendationForm from './components/LeaveRecommendationForm'
import Footer from './components/Footer'

import {
  profile,
  navLinks,
  skills,
  projects,
  initialRecommendations,
} from './data/portfolioData'
import './App.css'

// Componente principal: orquesta todas las secciones.
function App() {
  const [recommendations, setRecommendations] = useState(initialRecommendations)

  // Agrega una nueva recomendación enviada desde el formulario
  const addRecommendation = ({ author, message }) => {
    setRecommendations((prev) => [...prev, { id: Date.now(), author, message }])
  }

  return (
    <>
      <Header name={profile.name} email={profile.email} phone={profile.phone} links={navLinks} />

      <Container as="main" style={{ maxWidth: 960 }}>
        <Intro greeting={profile.greeting} about={profile.about} />
        <SkillsSection skills={skills} />
        <ProjectsSection projects={projects} />
        <RecommendationsSection recommendations={recommendations} />
        <LeaveRecommendationForm onSubmit={addRecommendation} />
      </Container>

      <Footer />
    </>
  )
}

export default App
