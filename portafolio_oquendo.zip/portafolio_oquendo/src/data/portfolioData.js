// Datos del portafolio. Mantenerlos separados de los componentes permite
// reutilizar cada componente pasando la información mediante props.

const DEVICON = 'https://cdn.jsdelivr.net/gh/devicons/devicon@v2.16.0/icons'

export const profile = {
  name: 'Jane Doe',
  email: 'jdoe@jeemail.com',
  phone: '+13456764598',
  greeting: "Hi, I'm Jane Doe!",
  about:
    'I am a full stack developer with 2 years of experience in both application and presentation layers. I have worked on applications and microservices deployed on IBM Cloud. I am an avid user of IBM Watson Services and have worked on Watson Assistant, NLU, Sentiment analyzer to name a few.',
}

export const navLinks = [
  { label: 'About Me', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Recommendations', href: '#recommendations' },
]

export const skills = [
  { name: 'HTML', experience: '2 years experience', icon: `${DEVICON}/html5/html5-original.svg` },
  { name: 'JavaScript', experience: '1.5 years experience', icon: `${DEVICON}/javascript/javascript-original.svg` },
  { name: 'Java', experience: '.5 years experience', icon: `${DEVICON}/java/java-original.svg` },
  { name: 'React', experience: '1 year experience', icon: `${DEVICON}/react/react-original.svg` },
  { name: 'Node.js', experience: '1 years experience', icon: `${DEVICON}/nodejs/nodejs-original.svg` },
  { name: 'CSS', experience: '2 years experience', icon: `${DEVICON}/css3/css3-original.svg` },
]

export const projects = [
  {
    title: 'Chatbot',
    description:
      'Developed a secure website integrated with chatbot for an automobile client using HTML, CSS, JavaScript and IBM Watson Assistant',
  },
  {
    title: 'Sentiment Analyzer',
    description:
      'Developed and deployed a sentiment analyzer for the box reviews section of an eCommerce platform using IBM NLU',
  },
  {
    title: 'Fashion Website',
    description:
      'Created a styled multi-page website for a new player in the fashion industry and integrated it with a shopping cart, using stripe for payment gateway',
  },
]

export const initialRecommendations = [
  {
    id: 1,
    author: '',
    message:
      'Jane is a very quick learner and quickly grasps key concepts of Web development. She got a great attitude & she is an excellent team player. She has a curious mind and asks the right question. She takes initiative within a team and has potentials to lead the team.',
  },
  {
    id: 2,
    author: '',
    message:
      'Working with Jane has been an awesome experience. She is highly knowledgable and always goes the extra step to make sure everything is right. For any future projects that need her expertise I would definitely want to work with her again.',
  },
  {
    id: 3,
    author: '',
    message:
      'I had worked along with Jane during the initial phase of our venture which needed Web development. She is a committed resource who has in depth knowledge about the domain. She will be an asset for any organisation!',
  },
]
