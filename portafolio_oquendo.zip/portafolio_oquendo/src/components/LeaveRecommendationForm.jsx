import { useState } from 'react'
import { Form, Button, Row, Col } from 'react-bootstrap'

// Formulario para dejar una recomendación.
// Recibe por props la función onSubmit definida en App (estado elevado).
function LeaveRecommendationForm({ onSubmit }) {
  const [name, setName] = useState('')
  const [message, setMessage] = useState('')

  const handleSubmit = (event) => {
    event.preventDefault()
    if (!message.trim()) return
    onSubmit({ author: name.trim(), message: message.trim() })
    setName('')
    setMessage('')
  }

  return (
    <section id="contact" className="py-4">
      <Row className="justify-content-center">
        <Col xs={12} md={8} lg={6}>
          <Form onSubmit={handleSubmit}>
            <h2 className="h5 mb-3">Leave a Recommendation</h2>

            <Form.Group className="mb-3" controlId="recommendationName">
              <Form.Label visuallyHidden>Name</Form.Label>
              <Form.Control
                type="text"
                size="sm"
                placeholder="Name (Optional)"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="recommendationMessage">
              <Form.Label visuallyHidden>Message</Form.Label>
              <Form.Control
                as="textarea"
                rows={6}
                placeholder="Message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
              />
            </Form.Group>

            <div className="text-center">
              <Button type="submit" variant="outline-primary" className="btn-submit">
                Submit
              </Button>
            </div>
          </Form>
        </Col>
      </Row>
    </section>
  )
}

export default LeaveRecommendationForm
