// Elemento individual de proyecto: título + descripción en viñeta.
function ProjectItem({ title, description }) {
  return (
    <div className="card-body px-0">
      <h3 className="project-title">{title}</h3>
      <ul className="project-description mb-0">
        <li>{description}</li>
      </ul>
    </div>
  )
}

export default ProjectItem
