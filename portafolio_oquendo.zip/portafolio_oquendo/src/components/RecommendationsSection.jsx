import { Row, Col } from 'react-bootstrap'
import RecommendationCard from './RecommendationCard'

// Sección de recomendaciones: 1 columna en móvil, 3 en pantallas medianas.
function RecommendationsSection({ recommendations }) {
  return (
    <section id="recommendations" className="py-4">
      <h2 className="section-title mb-4">Recommendations</h2>
      <Row className="g-3">
        {recommendations.map((rec) => (
          <Col key={rec.id} xs={12} md={4}>
            <RecommendationCard message={rec.message} author={rec.author} />
          </Col>
        ))}
      </Row>
    </section>
  )
}

export default RecommendationsSection
