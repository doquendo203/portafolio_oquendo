import { Row, Col } from 'react-bootstrap'
import SkillCard from './SkillCard'

// Sección de habilidades: cuadrícula responsiva de SkillCard.
// 2 por fila en móvil, 3 en tablet (col-md-4) y 4 en escritorio (col-lg-3).
function SkillsSection({ skills }) {
  return (
    <section id="skills" className="py-4">
      <h2 className="section-title mb-4">Skills</h2>
      <Row className="g-4">
        {skills.map((skill) => (
          <Col key={skill.name} xs={6} md={4} lg={3}>
            <SkillCard {...skill} />
          </Col>
        ))}
      </Row>
    </section>
  )
}

export default SkillsSection
