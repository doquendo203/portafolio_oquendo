import { Card } from 'react-bootstrap'

// Tarjeta individual de habilidad. Recibe sus datos por props.
function SkillCard({ name, experience, icon }) {
  return (
    <Card className="skill-card text-center h-100">
      <Card.Body className="d-flex flex-column align-items-center justify-content-center">
        <img src={icon} alt={`${name} logo`} className="mb-2" />
        <Card.Subtitle className="skill-name mb-3">{name}</Card.Subtitle>
        <Card.Text className="skill-years mb-0">{experience}</Card.Text>
      </Card.Body>
    </Card>
  )
}

export default SkillCard
