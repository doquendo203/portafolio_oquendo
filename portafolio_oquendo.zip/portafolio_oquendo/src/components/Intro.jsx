import { Row, Col, Image } from 'react-bootstrap'
import avatar from '../assets/avatar.svg'

// Sección de introducción "Hi, I'm Jane Doe!": avatar + texto.
function Intro({ greeting, about }) {
  return (
    <section id="about" className="py-5">
      <Row className="align-items-center g-4">
        <Col xs={12} md={5} className="text-center">
          {/* img-fluid -> imagen responsiva (fluid) */}
          <Image src={avatar} alt="Jane Doe avatar" fluid style={{ maxWidth: 260 }} />
        </Col>
        <Col xs={12} md={7}>
          <h1 className="intro-title">
            {greeting} <span aria-hidden="true">👋</span>
          </h1>
          <p className="intro-text">{about}</p>
        </Col>
      </Row>
    </section>
  )
}

export default Intro
