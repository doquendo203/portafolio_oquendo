import { Row, Col } from 'react-bootstrap'
import ProjectItem from './ProjectItem'

// Sección de proyectos: cada proyecto separado por una línea (hr).
function ProjectsSection({ projects }) {
  return (
    <section id="projects" className="py-4">
      <h2 className="section-title mb-4">Projects</h2>
      <Row className="justify-content-center">
        <Col xs={12} lg={11}>
          {projects.map((project, index) => (
            <div key={project.title} className="card border-0">
              <ProjectItem {...project} />
              {index < projects.length - 1 && <hr className="mx-auto w-75 text-secondary" />}
            </div>
          ))}
        </Col>
      </Row>
    </section>
  )
}

export default ProjectsSection
