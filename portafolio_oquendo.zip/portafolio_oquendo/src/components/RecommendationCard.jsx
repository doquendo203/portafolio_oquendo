import { Card } from 'react-bootstrap'

// Tarjeta de recomendación. El autor es opcional.
function RecommendationCard({ message, author }) {
  return (
    <Card className="recommendation-card h-100">
      <Card.Body>
        <Card.Text>&quot; {message} &quot;</Card.Text>
        {author && <footer className="recommendation-author text-end">— {author}</footer>}
      </Card.Body>
    </Card>
  )
}

export default RecommendationCard
