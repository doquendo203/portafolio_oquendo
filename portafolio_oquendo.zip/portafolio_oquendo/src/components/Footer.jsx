import { Button } from 'react-bootstrap'

// Footer: botón flotante "scroll to top" en la esquina inferior derecha.
function Footer() {
  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' })

  return (
    <footer className="pb-5">
      <Button
        className="scroll-top-btn"
        onClick={scrollToTop}
        aria-label="Scroll to top"
        title="Scroll to top"
      >
        <i className="bi bi-arrow-up fs-5"></i>
      </Button>
    </footer>
  )
}

export default Footer
