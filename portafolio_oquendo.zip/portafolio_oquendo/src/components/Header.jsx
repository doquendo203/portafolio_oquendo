import { Navbar, Nav, Container } from 'react-bootstrap'

// Header: nombre, información de contacto y enlaces de navegación.
// Usa el Navbar de Bootstrap (colapsable en pantallas pequeñas).
function Header({ name, email, phone, links }) {
  return (
    <Navbar expand="md" variant="dark" sticky="top" className="portfolio-navbar py-2">
      <Container>
        <Navbar.Brand href="#about" className="d-flex flex-column">
          <span>{name}</span>
          <span className="contact-line">
            <i className="bi bi-envelope-fill me-1"></i>
            {email}
          </span>
          <span className="contact-line">
            <i className="bi bi-telephone-fill me-1"></i>
            {phone}
          </span>
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="main-nav" />
        <Navbar.Collapse id="main-nav">
          <Nav className="ms-auto">
            {links.map((link) => (
              <Nav.Link key={link.href} href={link.href}>
                {link.label}
              </Nav.Link>
            ))}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default Header
