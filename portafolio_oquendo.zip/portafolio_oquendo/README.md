# Portafolio con React.js y Bootstrap

Actividad del módulo *Desarrollo Frontend con React.js* (ADSO).

## Ejecutar

```bash
npm install
npm run dev
```

## Estructura

```
src/
├── assets/avatar.svg
├── components/
│   ├── Header.jsx                  (Navbar de React-Bootstrap)
│   ├── Intro.jsx                   (Row/Col + Image fluid)
│   ├── SkillsSection.jsx / SkillCard.jsx
│   ├── ProjectsSection.jsx / ProjectItem.jsx
│   ├── RecommendationsSection.jsx / RecommendationCard.jsx
│   ├── LeaveRecommendationForm.jsx (Form, Form.Group, Form.Control, Button)
│   └── Footer.jsx                  (botón scroll to top)
├── data/portfolioData.js
├── App.jsx / App.css / index.css / main.jsx
```

## Componentes de Bootstrap usados

Navbar, Container, Row, Col, Card, Form, Button, Image (img-fluid), bootstrap-icons.
